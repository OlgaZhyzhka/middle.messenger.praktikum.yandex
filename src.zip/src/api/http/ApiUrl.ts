export const BASE_URL = 'https://ya-praktikum.tech/api/v2';

export const RESOURCE_URL = 'https://ya-praktikum.tech/api/v2/resources/';

export const WS_URL = 'wss://ya-praktikum.tech/ws/chats/'