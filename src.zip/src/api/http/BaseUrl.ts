const BASE_URL = 'https://ya-praktikum.tech/api/v2"';

export default BASE_URL;

