import EventBus from '@/core/EventBus';

const eventBus = new EventBus();

export default eventBus;
