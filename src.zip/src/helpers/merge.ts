import { Indexed } from "@/utils/types";

const isObject = (item: unknown): item is Indexed => {
  return typeof item === 'object' && item !== null && !Array.isArray(item);
}

function merge(lhs: Indexed, rhs: Indexed): Indexed {
  let stack = [{ lhs, rhs }];

  while (stack.length > 0) {
    let { lhs, rhs } = stack.pop()!;

    Object.keys(rhs).forEach((key) => {
      const rhsValue = rhs[key];
      if (isObject(rhsValue)) {
        if (!isObject(lhs[key])) {
          lhs[key] = {} as Indexed;
        }
        stack.push({ lhs: lhs[key] as Indexed, rhs: rhsValue });
      } else {
        lhs[key] = rhsValue;
      }
    });
  }

  return lhs;
}

export default merge;
