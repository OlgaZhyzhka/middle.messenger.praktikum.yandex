import ChatApi from '@/api/ChatApi';
import { WS_URL } from '@/api/http/ApiUrl';
import WS from '@/api/ws/WebSocket';
import router from '@/router/Router';
import { store } from '@/store';
import { actions } from '@/store/actions';
import { HTTP_CODES, ROUTES, WS_EVENTS } from '@/utils/enums';

const chatApi = new ChatApi();

export default class ChatService {
  private socket?: WS;

  public async connectToChat(userId: number, chatId: number): Promise<void> {
    const { token } = (await chatApi.getToken(chatId)) as { token: string };
    const url = `${WS_URL}${userId}/${chatId}/${token}`;
    this.socket = new WS(url);
    await this.socket.connect();

    this.socket.on(WS_EVENTS.message, (data) => {
      actions.addMessage(data);
      console.log('Data is received', data);
    });

    this.socket.on(WS_EVENTS.close, (event) => {
      console.log('Connection is closed', event);
    });

    this.socket.on(WS_EVENTS.error, (event) => {
      console.log('Error connection', event);
    });
  }

  public sendMessage(message: string): void {
    if (!this.socket) {
      throw new Error('Socket is not connected');
    }

    this.socket.send({ content: message, type: 'message' });
  }

  public getOldMessages(offset: number = 0): void {
    if (!this.socket) {
      throw new Error('Socket is not connected');
    }

    this.socket.send({ content: offset.toString(), type: 'get old' });
  }

  public disconnect(): void {
    if (this.socket) {
      this.socket.close();
    }
  }

  public async getChatUsers(id: number) {
    try {
      const res = await chatApi.getChatUsers(id);

      if (res.status !== HTTP_CODES.OK) {
        throw { type: 'requestErr', desc: res };
      }

      console.log(res);

      // const users = JSON.parse(res.response);
      // actions.setActiveChatUsers(users);
    } catch (error) {
      console.error(error);
      this.handleError(error);
    }
  }

  private handleError(error: any) {
    if (error.type === 'requestErr') {
      const customErr = error as any;

      if (customErr.desc.status === 401) {
        store.set({ user: null });
        router.go(ROUTES.Home);
      }

      if (customErr.desc.status === 404) {
        router.go(ROUTES.Error404);
      }

      if (customErr.desc.status === 500) {
        router.go(ROUTES.Error500);
      }
    }
  }
}
