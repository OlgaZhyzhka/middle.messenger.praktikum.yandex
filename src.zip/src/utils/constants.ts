export const rootQuery = '#app';

export const holder = '/icons/upload-avatar.svg';

export const contacts = [
  {
    id: '12121',
    firstName: 'Maria',
    login: 'Maria',
    lastName: 'Malnich',
    phone: '+7 999 999 99 99',
    chatName: 'Maria',
    lastMessage: 'Chatgram Web was updated.',
    time: '19:48',
    avatar: '/images/avatar2.jpg',
    unreadCount: 1,
  },
  {
    id: '45464',
    firstName: 'Maria2',
    login: 'Maria2',
    lastName: 'Malnich',
    phone: '+7 999 999 99 99',
    chatName: 'Maria2',
    lastMessage: 'Chatgram Web was updated.',
    time: '19:48',
    avatar: '/images/avatar2.jpg',
    unreadCount: 1,
  },
];

export const contactsMap = new Map(contacts.map((contact) => [contact.id, contact]));

export const currentUser = {
  firstName: 'Olga',
  secondName: 'Zhyzhka',
  avatar: '/images/avatar1.jpg',
  email: 'olga@gmail.com',
  phone: '+7 999 999 99 99',
  login: 'OlgaZH',
  chatName: 'OlgaZH',
};

export const chatMessages = [
  {
    id: '1',
    user_id: '12121',
    content: 'Привет, как дела?',
    time: '12:00',
    type: 'base',
    incoming: true,
    isRead: true,
  },
  {
    id: '2',
    user_id: '45464',
    content: 'Привет, все хорошо, спасибо!',
    time: '12:01',
    type: 'base',
    incoming: false,
    isRead: true,
  },
];
