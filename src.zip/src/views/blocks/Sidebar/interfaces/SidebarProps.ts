import { Props } from '@/core/Block';

export interface SidebarProps extends Props {
  isMessenger?: boolean;
  isSettings?: boolean;
}
