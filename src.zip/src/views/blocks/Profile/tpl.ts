const tpl = `<div class="container">
{{{ profileCard }}}
</div>`;
export default tpl;
