const tpl = `{{{ avatar }}} <div class="contact__info"><span class="contact__title title">{{ name }}</span></div>`;
export default tpl;
