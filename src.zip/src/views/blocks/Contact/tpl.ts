const tpl = `{{{ avatar }}} <div class="contact__info"><span class="contact__title title">{{ login }}</span></div>`;
export default tpl;
