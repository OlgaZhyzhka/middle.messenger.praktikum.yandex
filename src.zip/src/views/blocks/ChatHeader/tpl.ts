const tpl = `<div class="chat__avatar">{{{  avatar }}} <span class="chat__title">{{ title }}</span></div><div class="actions">{{{ dropdown }}}</div></div>`;
export default tpl;
