import { Props } from '@/core/Block';

export interface ChatHeaderProps extends Props {
  opponentId: string;
}
