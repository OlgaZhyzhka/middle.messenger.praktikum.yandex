export { default as ProfilePassword } from './ProfilePassword';
