const tpl = `{{{ emailInput }}} {{{ loginInput }}} {{{ firstNameInput }}} {{{ lastNameInput }}} {{{ phoneInput }}} {{{ passwordInput }}}{{{ confirmPasswordInput }}}
<div class="form__footer">
{{{ submitButton }}}
<span class="form__text">{{ text }}</span>
{{{ linkButton }}}
</div>`;

export default tpl;
