const tpl = `{{{ emailInput }}} {{{ loginInput }}} {{{ firstNameInput }}} {{{ secondNameInput }}} {{{ phoneInput }}} {{{ passwordInput }}}{{{ confirmPasswordInput }}}
<div class="form__footer">
{{{ submitButton }}}
<span class="form__text">{{ text }}</span>
{{{ navButton }}}
</div>`;

export default tpl;
