const tpl = ` <div class="contacts__container">{{{ search }}}{{{ contactsList }}}</div>`;
export default tpl;
