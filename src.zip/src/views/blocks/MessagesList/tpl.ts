const tpl = `{{{ chatMessages }}}`;
export default tpl;
