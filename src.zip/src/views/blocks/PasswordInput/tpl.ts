const tpl = `{{{ inputElement }}}{{{ inputAddon }}}`;

export default tpl;
