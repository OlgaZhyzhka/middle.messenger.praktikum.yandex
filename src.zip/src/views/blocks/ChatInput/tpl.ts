const tpl = `{{{ chatInput }}}{{{ dropdown }}}{{{ sendButton }}}{{{ fileInputMedia }}}{{{ fileInputFile }}}{{{ fileInputLocation }}}`;
export default tpl;
