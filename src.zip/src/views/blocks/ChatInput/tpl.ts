const tpl = `{{{ chatInput }}}{{{ dropdown }}}{{{ sendButton }}}{{{ fileInputMedia }}}{{{ fileInputFile }}}`;
export default tpl;
