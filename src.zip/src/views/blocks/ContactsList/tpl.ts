const tpl = `{{{ contacts }}}`;
export default tpl;
