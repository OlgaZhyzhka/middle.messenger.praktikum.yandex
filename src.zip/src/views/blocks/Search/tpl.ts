const tpl = `{{{ searchInput }}}{{{ searchIcon }}}`;
export default tpl;
