const tpl = `{{{ message }}}`;
export default tpl;
