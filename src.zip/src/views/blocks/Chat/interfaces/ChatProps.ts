import { Props } from "@/core/Block";

export interface ChatProps extends Props {
  userId: number;
  chatId: number;
}
