const tpl = `{{{ tabs }}}`;
export default tpl;
