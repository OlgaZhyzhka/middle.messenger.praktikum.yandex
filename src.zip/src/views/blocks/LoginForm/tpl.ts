const tpl = `{{{ loginInput }}} {{{ passwordInput }}}
<div class="form__footer">
{{{ submitButton }}}
<span class="form__text">{{ text }}</span>
{{{ linkButton }}}
</div>`;
export default tpl;
