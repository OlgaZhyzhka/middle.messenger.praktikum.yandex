export { default as ModalUploadAvatar } from './ModalUploadAvatar';
