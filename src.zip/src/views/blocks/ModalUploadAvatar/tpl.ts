const tpl = `<h2 class="heading">{{ title }}</h2> 
{{{ uploadAvatar }}}
<div class="form__footer">
{{{ submitButton }}}
{{{ cancelButton }}}
</div>`;
export default tpl;
