export { default as Registration } from './Registration';
