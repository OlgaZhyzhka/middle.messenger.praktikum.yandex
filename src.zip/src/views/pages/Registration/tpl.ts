const tpl = `<h1 class="form__title">{{ pageTitle }}</h1> {{{registrationForm}}}`;

export default tpl;
