const tpl = `<div class="page__container"><img src="{{ imgSrc }}" alt="{{ imgAlt }}">
  <h1 class="page__heading page__heading_lg">{{ pageTitle }}</h1>
  <h4 class='page__title page__title_lg'>we'll fix it soon</p></h4>{{{ link }}}</div>`;
export default tpl;
