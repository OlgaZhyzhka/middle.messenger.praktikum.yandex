const tpl = `
  <h1 class="page__heading">{{ pageTitle }}</h1>
  {{{ links }}}
`;

export default tpl;
