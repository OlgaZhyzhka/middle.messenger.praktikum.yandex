const tpl = `
  <h1 class="page__heading">{{ pageTitle }}</h1>
`;

export default tpl;
