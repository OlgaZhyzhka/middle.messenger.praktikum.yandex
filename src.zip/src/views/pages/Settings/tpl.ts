const tpl = `{{{sidebar}}}<div class="page__section">{{{settings}}}</div>`;

export default tpl;
