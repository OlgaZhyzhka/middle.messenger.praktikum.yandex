const tpl = `<div class="page__section">{{{sidebar}}}<div class="page__column">{{{ profile }}}</div></div>`;

export default tpl;
