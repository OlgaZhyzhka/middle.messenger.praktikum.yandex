export { default as BasePage } from './BasePage';
