const tpl = `{{{sidebar}}}{{{contactsPanel}}}<div class="page__section">{{{chat}}}</div>`;

export default tpl;
