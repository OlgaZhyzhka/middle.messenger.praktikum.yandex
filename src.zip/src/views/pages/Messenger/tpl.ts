const tpl = `<div class="page__section">{{{sidebar}}}{{{contactsPanel}}}<div class="page__column">{{{chat}}}</div></div>`;

export default tpl;
