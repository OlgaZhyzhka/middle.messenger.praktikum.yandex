const tpl = `<img src="{{ imgSrc }}" alt="{{ imgAlt }}"> <h1 class="form__title">{{ pageTitle }}</h1> {{{loginForm}}}`;

export default tpl;
