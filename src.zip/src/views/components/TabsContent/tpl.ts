const tpl = `{{{ content }}}`;

export default tpl;
