import Block, { Props } from '@/core/Block';

export interface TabsContentProps extends Props {
  content?: Block | null;
}
