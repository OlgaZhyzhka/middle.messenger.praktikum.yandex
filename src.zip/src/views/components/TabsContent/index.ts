export { default as TabsContent } from './TabsContent';
