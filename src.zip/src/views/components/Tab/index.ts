export { default as Tab } from './Tab';
