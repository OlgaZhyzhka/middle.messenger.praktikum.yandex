const tpl = `{{ title }}`;

export default tpl;
