const tpl = `{{{ tabsNav }}}`;

export default tpl;
