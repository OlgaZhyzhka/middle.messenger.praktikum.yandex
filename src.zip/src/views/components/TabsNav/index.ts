export { default as Tabs } from './TabsNav';
