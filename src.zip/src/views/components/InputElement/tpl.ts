const tpl = `{{{ input }}}{{#unless isValid}}{{{ errorText }}}{{/unless}} `;

export default tpl;
