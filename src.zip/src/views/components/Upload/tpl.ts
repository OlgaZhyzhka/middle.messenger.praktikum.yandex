const tpl = `<label for="{{ uploadId }}">
{{{ inputFile }}}
{{{ uploadIcon }}}
{{{ uploadPreview }}}
</label>`;

export default tpl;
