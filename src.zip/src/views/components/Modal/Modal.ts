import Block, { Props } from '@/core/Block';
import { ModalProps } from './interfaces/ModalProps';
import tpl from './tpl';

class Modal extends Block {
  constructor(props: ModalProps & Props) {
    super(props);
    const { size } = props;

    const sizeClass = size ? `modal_${size}` : '';
    const className = `modal ${sizeClass}`.trim();

    this.setProps({
      attributes: {
        ...props.attributes,
        class: `${props.attributes?.class ? props.attributes?.class : ''} ${className}`.trim(),
      },
      events: {
        click: (event: Event) => this.handleClose(event),
      },
    });
  }

  handleClose(event: Event): void {
    if (event.target === this.element) {
      if (typeof this.props.onClose === 'function') {
        this.props.onClose();
      }
    }
  }

  public render(): DocumentFragment {
    return this.compile(tpl);
  }
}

export default Modal;
