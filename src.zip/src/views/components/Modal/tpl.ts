const tpl = ``;

export default tpl;
