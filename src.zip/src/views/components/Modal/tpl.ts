const tpl = `{{{ modalBg }}}
  <div class="modal__container">
    {{{ buttonClose }}}
    <div class="modal__body">{{{content}}}</div>
  </div>`;

export default tpl;
