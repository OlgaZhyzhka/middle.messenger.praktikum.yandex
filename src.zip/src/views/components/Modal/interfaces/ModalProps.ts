import { SIZE } from "@/utils/types";

export interface ModalProps {
  size: SIZE;
  isOpen: boolean;
  onClose: () => void;
}
