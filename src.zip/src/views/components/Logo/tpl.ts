const tpl = `{{{ logoLink }}}`;

export default tpl;
