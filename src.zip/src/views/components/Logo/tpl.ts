const tpl = `<a class='logo' href="/"><img src="{{ src }}" alt="{{ text }}"><span class='logo__title'>{{ text }}</span></a>`;

export default tpl;
