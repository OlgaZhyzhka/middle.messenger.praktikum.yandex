import { DropdownItemProps } from "@/views/components/DropdownItem/interfaces/DropdownItemProps";

export interface DropdownProps {
  type: string;
  items: DropdownItemProps[];
}