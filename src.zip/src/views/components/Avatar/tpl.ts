const tpl = `<img src="{{ src }}" alt="{{ title }}" class="avatar__image" />`;

export default tpl;
