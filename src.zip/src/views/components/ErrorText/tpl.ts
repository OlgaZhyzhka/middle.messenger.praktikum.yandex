const tpl = `{{ text }}`;

export default tpl;
