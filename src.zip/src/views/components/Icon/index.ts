export { default as Icon } from './Icon';
