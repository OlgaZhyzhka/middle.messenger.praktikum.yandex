const tpl = `{{{ tabsNav }}}{{{ tabsContent }}}`;

export default tpl;
