export interface LabelProps {
  for?: string;
}