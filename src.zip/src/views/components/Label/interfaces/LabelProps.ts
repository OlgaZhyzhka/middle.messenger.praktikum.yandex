import { Props } from '@/core/Block';

export interface LabelProps extends Props {
  for?: string;
}
