const tpl = `<div class="spinner__wrapper"><span class="spinner__circle"></span></div>`;

export default tpl;
