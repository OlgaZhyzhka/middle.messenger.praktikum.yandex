import { Props } from "@/core/Block";

export interface LinkProps extends Props {
  text: string;
}
