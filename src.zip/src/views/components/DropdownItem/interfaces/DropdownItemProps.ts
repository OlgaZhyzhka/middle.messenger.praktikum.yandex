export interface DropdownItemProps {
  iconName: string,
  title: string;
  inputId?: string;
  onClick?: (event: Event) => void;
  onToggle?: (event: Event) => void;
}
