const tpl = `{{#if labelUpload }}{{{ labelUpload }}}{{else}}{{{ children }}}{{/if}}`;

export default tpl;
